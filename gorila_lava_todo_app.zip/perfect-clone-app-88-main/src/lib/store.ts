// Store using Supabase for persistence
import { supabase } from "@/integrations/supabase/client";

export type ServiceType = "lavado" | "tapiceria";
export type PaymentMethod = "efectivo" | "qr";
export type VehicleCombo = 1 | 2 | 3 | 4 | 5;

export interface TapiceriaItemConfig {
  type: string;
  hours: number;
  id?: number;
}

export interface VehicleSize {
  id: number;
  name: string;
  price: number;
  sort_order: number;
}

export interface Appointment {
  id: string;
  date: string;
  time: string;
  clientName: string;
  manzana: string;
  casa: string;
  phone: string;
  serviceType: ServiceType;
  vehicleCount?: number;
  combo?: VehicleCombo;
  tapiceriaItems?: { type: string; quantity: number }[];
  paymentMethod: PaymentMethod;
  durationHours: number;
  status: "pendiente" | "en_proceso" | "completado" | "cancelado";
  price?: number;
  vehicleSizeName?: string;
  vehicleSizePrice?: number;
}

export interface AdminConfig {
  whatsappNumber: string;
  qrImageBase64: string;
  breakEnabled: boolean;
  breakStart: string;
  breakEnd: string;
}

export interface WorkSchedule {
  [dayOfWeek: number]: { enabled: boolean; start: string; end: string; interval: number };
}

// Combo durations in hours
export const COMBO_DURATIONS: Record<VehicleCombo, number> = {
  1: 1, 2: 1.5, 3: 2.5, 4: 3, 5: 4,
};

export const COMBO_SERVICES: Record<VehicleCombo, string[]> = {
  1: ["Lavado exterior a presión", "Aspirado y Siliconeado Interior", "Abrillantado de llantas y plásticos exteriores"],
  2: ["Lavado exterior a presión", "Aspirado y Siliconeado Interior", "Abrillantado de llantas y plásticos exteriores", "Encerado del exterior"],
  3: ["Lavado exterior a presión", "Aspirado y Siliconeado Interior", "Abrillantado de llantas y plásticos exteriores", "Encerado del exterior", "Lavado a detalle de asientos con Hidroaspiradora"],
  4: ["Lavado exterior a presión", "Aspirado y Siliconeado Interior", "Hidratación de Cuero", "Abrillantado de llantas y plásticos exteriores", "Encerado del exterior", "Lavado a detalle de asientos con Hidroaspiradora", "Lavado de Motor a vapor"],
  5: ["Lavado exterior a presión", "Aspirado y Siliconeado Interior", "Hidratación de Cuero", "Abrillantado de llantas y plásticos exteriores", "Encerado del exterior", "Lavado a detalle de asientos con Hidroaspiradora", "Lavado de Motor a vapor", "Lavado de techo y alfombra"],
};

// --- Helpers ---
const parseToMinutes = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};

const formatTime = (mins: number) => {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}`;
};

const addHoursToTime = (time: string, hours: number): string => {
  const totalMin = parseToMinutes(time) + hours * 60;
  return formatTime(Math.round(totalMin));
};

// --- Vehicle Sizes ---

export const getVehicleSizes = async (): Promise<VehicleSize[]> => {
  const { data } = await supabase.from("vehicle_sizes").select("*").order("sort_order");
  return (data || []).map((r: any) => ({ id: r.id, name: r.name, price: Number(r.price), sort_order: r.sort_order }));
};

export const addVehicleSize = async (name: string, price: number, sort_order: number) => {
  await supabase.from("vehicle_sizes").insert({ name, price, sort_order });
};

export const updateVehicleSize = async (id: number, name: string, price: number) => {
  await supabase.from("vehicle_sizes").update({ name, price }).eq("id", id);
};

export const deleteVehicleSize = async (id: number) => {
  await supabase.from("vehicle_sizes").delete().eq("id", id);
};

// --- Appointments ---

const toAppointment = (row: any): Appointment => ({
  id: row.id,
  date: row.date,
  time: row.time,
  clientName: row.client_name,
  manzana: row.manzana || "",
  casa: row.casa || "",
  phone: row.phone || "",
  serviceType: row.service_type as ServiceType,
  vehicleCount: row.vehicle_count ?? undefined,
  combo: row.combo as VehicleCombo | undefined,
  tapiceriaItems: row.tapiceria_items as any,
  paymentMethod: row.payment_method as PaymentMethod,
  durationHours: Number(row.duration_hours),
  status: row.status,
  price: row.price ? Number(row.price) : undefined,
  vehicleSizeName: row.vehicle_size_name || undefined,
  vehicleSizePrice: row.vehicle_size_price ? Number(row.vehicle_size_price) : undefined,
});

export const getAppointmentsByDate = async (date: string): Promise<Appointment[]> => {
  const { data } = await supabase.from("appointments").select("*").eq("date", date);
  return (data || []).map(toAppointment);
};

export const addAppointment = async (appt: Omit<Appointment, "id" | "status">): Promise<Appointment | null> => {
  const { data } = await supabase.from("appointments").insert({
    date: appt.date,
    time: appt.time,
    client_name: appt.clientName,
    manzana: appt.manzana,
    casa: appt.casa,
    phone: appt.phone,
    service_type: appt.serviceType,
    vehicle_count: appt.vehicleCount ?? null,
    combo: appt.combo ?? null,
    tapiceria_items: appt.tapiceriaItems as any,
    payment_method: appt.paymentMethod,
    duration_hours: appt.durationHours,
    vehicle_size_name: appt.vehicleSizeName ?? null,
    vehicle_size_price: appt.vehicleSizePrice ?? null,
  }).select().single();
  return data ? toAppointment(data) : null;
};

export const updateAppointmentStatus = async (id: string, status: Appointment["status"]) => {
  await supabase.from("appointments").update({ status }).eq("id", id);
};

export const updateAppointmentPrice = async (id: string, price: number) => {
  await supabase.from("appointments").update({ price, status: "completado" }).eq("id", id);
};

export const deleteAppointment = async (id: string) => {
  await supabase.from("appointments").delete().eq("id", id);
};

export const cancelAppointmentByName = async (name: string, date: string): Promise<boolean> => {
  const { data } = await supabase
    .from("appointments")
    .select("id")
    .eq("date", date)
    .ilike("client_name", name)
    .neq("status", "cancelado")
    .limit(1);
  if (data && data.length > 0) {
    await supabase.from("appointments").update({ status: "cancelado" }).eq("id", data[0].id);
    return true;
  }
  return false;
};

export const getOccupiedSlots = async (date: string, allSlots: string[]): Promise<Set<string>> => {
  const appointments = (await getAppointmentsByDate(date)).filter((a) => a.status !== "cancelado");
  const occupied = new Set<string>();

  const getSlotIntervalMinutes = (slots: string[]) => {
    if (slots.length < 2) return 60;
    let best = Infinity;
    for (let i = 0; i < Math.min(slots.length - 1, 6); i++) {
      const diff = parseToMinutes(slots[i + 1]) - parseToMinutes(slots[i]);
      if (diff > 0) best = Math.min(best, diff);
    }
    return Number.isFinite(best) ? best : 60;
  };

  const slotMinutes = getSlotIntervalMinutes(allSlots);

  for (const appt of appointments) {
    const startIdx = allSlots.indexOf(appt.time);
    if (startIdx === -1) continue;
    const slotsNeeded = Math.max(1, Math.ceil((appt.durationHours * 60) / slotMinutes));
    for (let i = 0; i < slotsNeeded && startIdx + i < allSlots.length; i++) {
      occupied.add(allSlots[startIdx + i]);
    }
  }
  return occupied;
};

export const getBreakSlots = async (allSlots: string[], adminConfig?: AdminConfig): Promise<Set<string>> => {
  const config = adminConfig || await getAdminConfig();
  if (!config.breakEnabled) return new Set();
  const breakStart = parseToMinutes(config.breakStart);
  const breakEnd = parseToMinutes(config.breakEnd);
  const breakSet = new Set<string>();
  for (const slot of allSlots) {
    const slotMin = parseToMinutes(slot);
    if (slotMin >= breakStart && slotMin < breakEnd) {
      breakSet.add(slot);
    }
  }
  return breakSet;
};

export const canFitAppointment = async (
  date: string,
  startTime: string,
  durationHours: number,
  allSlots: string[]
): Promise<boolean> => {
  const occupied = await getOccupiedSlots(date, allSlots);

  const getSlotIntervalMinutes = (slots: string[]) => {
    if (slots.length < 2) return 60;
    let best = Infinity;
    for (let i = 0; i < Math.min(slots.length - 1, 6); i++) {
      const diff = parseToMinutes(slots[i + 1]) - parseToMinutes(slots[i]);
      if (diff > 0) best = Math.min(best, diff);
    }
    return Number.isFinite(best) ? best : 60;
  };

  const startIdx = allSlots.indexOf(startTime);
  if (startIdx === -1) return false;
  const slotMinutes = getSlotIntervalMinutes(allSlots);
  const slotsNeeded = Math.max(1, Math.ceil((durationHours * 60) / slotMinutes));
  for (let i = 0; i < slotsNeeded && startIdx + i < allSlots.length; i++) {
    if (occupied.has(allSlots[startIdx + i])) return false;
  }
  return startIdx + slotsNeeded <= allSlots.length;
};

// --- Daily Summary ---

export const getDailySummary = async (date: string) => {
  const appts = (await getAppointmentsByDate(date)).filter((a) => a.status !== "cancelado");
  const completed = appts.filter((a) => a.status === "completado");
  const totalHours = appts.reduce((sum, a) => sum + a.durationHours, 0);
  const totalEarnings = completed.reduce((sum, a) => sum + (a.price || 0), 0);
  const sorted = [...appts].sort((a, b) => a.time.localeCompare(b.time));
  const firstTime = sorted.length > 0 ? sorted[0].time : null;
  const lastAppt = sorted.length > 0 ? sorted[sorted.length - 1] : null;
  const lastTime = lastAppt ? addHoursToTime(lastAppt.time, lastAppt.durationHours) : null;
  return { appts, completed, totalHours, totalEarnings, firstTime, lastTime };
};

// --- Work Schedule ---

// Cache for admin config to avoid repeated fetches
let cachedAdminConfig: AdminConfig | null = null;
let cachedAdminConfigTime = 0;
const CACHE_TTL = 30000; // 30 seconds

export const getSchedule = async (): Promise<WorkSchedule> => {
  const { data } = await supabase.from("work_schedule").select("*").order("day_of_week");
  if (!data || data.length === 0) {
    return {
      0: { enabled: false, start: "08:30", end: "16:00", interval: 30 },
      1: { enabled: true, start: "08:30", end: "16:00", interval: 30 },
      2: { enabled: true, start: "08:30", end: "16:00", interval: 30 },
      3: { enabled: true, start: "08:30", end: "16:00", interval: 30 },
      4: { enabled: true, start: "08:30", end: "16:00", interval: 30 },
      5: { enabled: true, start: "08:30", end: "16:00", interval: 30 },
      6: { enabled: true, start: "08:30", end: "16:00", interval: 30 },
    };
  }
  const schedule: WorkSchedule = {};
  data.forEach((row) => {
    schedule[row.day_of_week] = {
      enabled: row.enabled,
      start: row.start_time,
      end: row.end_time,
      interval: row.interval_minutes,
    };
  });
  return schedule;
};

export const saveScheduleDay = async (day: number, config: { enabled: boolean; start: string; end: string; interval: number }) => {
  await supabase.from("work_schedule").update({
    enabled: config.enabled,
    start_time: config.start,
    end_time: config.end,
    interval_minutes: config.interval,
  }).eq("day_of_week", day);
};

export const getTimeSlots = async (date: Date): Promise<string[]> => {
  const schedule = await getSchedule();
  const dayConfig = schedule[date.getDay()];
  if (!dayConfig || !dayConfig.enabled) return [];

  const start = parseToMinutes(dayConfig.start);
  const end = parseToMinutes(dayConfig.end);
  const interval = dayConfig.interval;
  const config = await getAdminConfig();
  const slots: string[] = [];

  if (config.breakEnabled) {
    const breakStart = parseToMinutes(config.breakStart);
    const breakEnd = parseToMinutes(config.breakEnd);
    let current = start;
    while (current < end && current < breakStart) {
      slots.push(formatTime(current));
      current += interval;
    }
    if (breakStart >= start && breakStart < end && !slots.includes(formatTime(breakStart))) {
      slots.push(formatTime(breakStart));
    }
    current = breakEnd;
    while (current < end) {
      slots.push(formatTime(current));
      current += interval;
    }
  } else {
    let current = start;
    while (current < end) {
      slots.push(formatTime(current));
      current += interval;
    }
  }

  const unique = [...new Set(slots)].sort((a, b) => parseToMinutes(a) - parseToMinutes(b));
  return unique;
};

// --- Admin Config ---

export const getAdminConfig = async (): Promise<AdminConfig> => {
  const now = Date.now();
  if (cachedAdminConfig && (now - cachedAdminConfigTime) < CACHE_TTL) {
    return cachedAdminConfig;
  }
  const { data } = await supabase.from("admin_config").select("*").eq("id", 1).single();
  const config = data ? {
    whatsappNumber: data.whatsapp_number || "",
    qrImageBase64: data.qr_image_base64 || "",
    breakEnabled: data.break_enabled ?? true,
    breakStart: data.break_start || "12:00",
    breakEnd: data.break_end || "12:30",
  } : { whatsappNumber: "", qrImageBase64: "", breakEnabled: true, breakStart: "12:00", breakEnd: "12:30" };
  cachedAdminConfig = config;
  cachedAdminConfigTime = now;
  return config;
};

export const saveAdminConfig = async (config: AdminConfig) => {
  cachedAdminConfig = config;
  cachedAdminConfigTime = Date.now();
  await supabase.from("admin_config").upsert({
    id: 1,
    whatsapp_number: config.whatsappNumber,
    qr_image_base64: config.qrImageBase64,
    break_enabled: config.breakEnabled,
    break_start: config.breakStart,
    break_end: config.breakEnd,
  });
};

// --- Tapicería Items ---

export const getTapiceriaItems = async (): Promise<TapiceriaItemConfig[]> => {
  const { data } = await supabase.from("tapiceria_items").select("*").order("id");
  return (data || []).map((r) => ({ id: r.id, type: r.type, hours: Number(r.hours) }));
};

export const saveTapiceriaItem = async (id: number, type: string, hours: number) => {
  await supabase.from("tapiceria_items").update({ type, hours }).eq("id", id);
};

export const addTapiceriaItem = async (type: string, hours: number) => {
  await supabase.from("tapiceria_items").insert({ type, hours });
};

export const deleteTapiceriaItem = async (id: number) => {
  await supabase.from("tapiceria_items").delete().eq("id", id);
};

export const ADMIN_CODE = "202609";

// --- Daily Reports ---

export interface DailyReport {
  id: string;
  reportDate: string;
  appointmentsData: any[];
  totalEarnings: number;
  totalServices: number;
  createdAt: string;
}

export const saveDailyReport = async (date: string, appointments: Appointment[]) => {
  const totalEarnings = appointments.reduce((sum, a) => sum + (a.price || 0), 0);
  const totalServices = appointments.length;
  const { data } = await supabase.from("daily_reports").select("id").eq("report_date", date).single();
  if (data) {
    await supabase.from("daily_reports").update({
      appointments_data: appointments as any,
      total_earnings: totalEarnings,
      total_services: totalServices,
    }).eq("report_date", date);
  } else {
    await supabase.from("daily_reports").insert([{
      report_date: date,
      appointments_data: appointments as any,
      total_earnings: totalEarnings,
      total_services: totalServices,
    }]);
  }
};

export const getDailyReport = async (date: string): Promise<DailyReport | null> => {
  const { data } = await supabase.from("daily_reports").select("*").eq("report_date", date).single();
  if (!data) return null;
  return {
    id: data.id,
    reportDate: data.report_date,
    appointmentsData: data.appointments_data as any[],
    totalEarnings: Number(data.total_earnings),
    totalServices: data.total_services,
    createdAt: data.created_at,
  };
};

export const getAllReports = async (): Promise<DailyReport[]> => {
  const { data } = await supabase.from("daily_reports").select("*").order("report_date", { ascending: false });
  return (data || []).map((r) => ({
    id: r.id,
    reportDate: r.report_date,
    appointmentsData: r.appointments_data as any[],
    totalEarnings: Number(r.total_earnings),
    totalServices: r.total_services,
    createdAt: r.created_at,
  }));
};

export const deleteReportsByPeriod = async (period: "week" | "month" | "quarter") => {
  const today = new Date();
  let cutoffDate: Date;
  switch (period) {
    case "week": cutoffDate = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000); break;
    case "month": cutoffDate = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000); break;
    case "quarter": cutoffDate = new Date(today.getTime() - 90 * 24 * 60 * 60 * 1000); break;
  }
  const cutoffStr = cutoffDate.toISOString().split("T")[0];
  await supabase.from("daily_reports").delete().lt("report_date", cutoffStr);
};

export const deleteOldReports = async () => {
  const cutoffDate = new Date(Date.now() - 45 * 24 * 60 * 60 * 1000);
  const cutoffStr = cutoffDate.toISOString().split("T")[0];
  await supabase.from("daily_reports").delete().lt("report_date", cutoffStr);
};
