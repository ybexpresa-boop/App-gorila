import { useState, useEffect, useCallback } from "react";
import { useNavigate, Link } from "react-router-dom";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  getAppointmentsByDate, updateAppointmentStatus, deleteAppointment,
  getSchedule, saveScheduleDay, getAdminConfig, saveAdminConfig,
  updateAppointmentPrice, getDailySummary,
  getTapiceriaItems, saveTapiceriaItem, addTapiceriaItem, deleteTapiceriaItem,
  getVehicleSizes, addVehicleSize, updateVehicleSize, deleteVehicleSize,
  saveDailyReport, deleteOldReports, deleteReportsByPeriod,
  type Appointment, type WorkSchedule, type AdminConfig, type TapiceriaItemConfig, type VehicleSize,
} from "@/lib/store";
import CalendarStrip from "@/components/CalendarStrip";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Trash2, CheckCircle, Play, Upload, Phone, DollarSign, Clock, TrendingUp, Plus, Pencil, Copy, Car } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import logo from "@/assets/logo.jpg";

const DAY_NAMES = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];

const calculateEndTime = (time: string, durationHours: number): string => {
  const [h, m] = time.split(":").map(Number);
  const totalMins = h * 60 + m + Math.round(durationHours * 60);
  return `${String(Math.floor(totalMins / 60)).padStart(2, "0")}:${String(totalMins % 60).padStart(2, "0")}`;
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [tab, setTab] = useState<"agenda" | "resumen" | "reportes" | "horarios" | "config">("agenda");
  const [schedule, setSchedule] = useState<WorkSchedule>({});
  const [adminConfig, setAdminConfig] = useState<AdminConfig>({ whatsappNumber: "", qrImageBase64: "", breakEnabled: true, breakStart: "12:00", breakEnd: "12:30" });
  const [priceInputs, setPriceInputs] = useState<Record<string, string>>({});
  const [tapiceriaItems, setTapiceriaItemsState] = useState<TapiceriaItemConfig[]>([]);
  const [editingTapiceria, setEditingTapiceria] = useState<number | null>(null);
  const [tapiceriaForm, setTapiceriaForm] = useState({ type: "", hours: "" });
  const [showAddTapiceria, setShowAddTapiceria] = useState(false);
  const [vehicleSizesState, setVehicleSizesState] = useState<VehicleSize[]>([]);
  const [editingVehicleSize, setEditingVehicleSize] = useState<number | null>(null);
  const [vehicleSizeForm, setVehicleSizeForm] = useState({ name: "", price: "" });
  const [showAddVehicleSize, setShowAddVehicleSize] = useState(false);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (sessionStorage.getItem("gorila_admin") !== "true") {
      navigate("/admin");
      return;
    }
    // Load initial data and clean old reports
    Promise.all([getSchedule(), getAdminConfig(), getTapiceriaItems(), getVehicleSizes(), deleteOldReports()]).then(([s, c, t, vs]) => {
      setSchedule(s);
      setAdminConfig(c);
      setTapiceriaItemsState(t);
      setVehicleSizesState(vs);
      setLoading(false);
    });
  }, [navigate]);

  const dateStr = format(selectedDate, "yyyy-MM-dd");

  const refresh = useCallback(async () => {
    const appts = await getAppointmentsByDate(dateStr);
    setAppointments(appts);
    const prices: Record<string, string> = {};
    appts.forEach((a) => { if (a.price) prices[a.id] = String(a.price); });
    setPriceInputs(prices);
    const s = await getDailySummary(dateStr);
    setSummary(s);
  }, [dateStr]);

  useEffect(() => { refresh(); }, [refresh]);

  const handleStatus = async (id: string, status: Appointment["status"]) => {
    await updateAppointmentStatus(id, status);
    await refresh();
    toast.success("Estado actualizado");
  };

  const handleDelete = async (id: string) => {
    await deleteAppointment(id);
    await refresh();
    toast.success("Cita eliminada");
  };

  const handleMarkAsPaid = async (id: string, currentPrice?: number) => {
    let price = currentPrice;
    if (!price) {
      const inputPrice = parseFloat(priceInputs[id] || "0");
      if (inputPrice <= 0) { toast.error("Ingresa un precio válido primero"); return; }
      price = inputPrice;
    }
    await updateAppointmentPrice(id, price);
    await refresh();
    // Save daily report when marking as paid
    const appts = await getAppointmentsByDate(dateStr);
    await saveDailyReport(dateStr, appts);
    toast.success("Marcado como pagado y agregado a ganancias");
  };

  const handleScheduleChange = async (day: number, field: string, value: any) => {
    const updated = { ...schedule, [day]: { ...schedule[day], [field]: value } };
    setSchedule(updated);
    await saveScheduleDay(day, updated[day]);
    toast.success("Horario guardado");
  };

  const handleWhatsappSave = async () => {
    await saveAdminConfig(adminConfig);
    toast.success("WhatsApp actualizado");
  };

  const handleQRUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const updated = { ...adminConfig, qrImageBase64: reader.result as string };
      setAdminConfig(updated);
      await saveAdminConfig(updated);
      toast.success("QR actualizado");
    };
    reader.readAsDataURL(file);
  };

  const handleSaveTapiceriaItem = async (index: number) => {
    const item = tapiceriaItems[index];
    if (!item.id) return;
    await saveTapiceriaItem(item.id, tapiceriaForm.type, parseFloat(tapiceriaForm.hours) || 2);
    const updated = await getTapiceriaItems();
    setTapiceriaItemsState(updated);
    setEditingTapiceria(null);
    toast.success("Artículo actualizado");
  };

  const handleAddTapiceriaItem = async () => {
    if (!tapiceriaForm.type.trim()) { toast.error("Ingresa un nombre"); return; }
    await addTapiceriaItem(tapiceriaForm.type.trim(), parseFloat(tapiceriaForm.hours) || 2);
    const updated = await getTapiceriaItems();
    setTapiceriaItemsState(updated);
    setShowAddTapiceria(false);
    setTapiceriaForm({ type: "", hours: "" });
    toast.success("Artículo agregado");
  };

  const handleDeleteTapiceriaItem = async (index: number) => {
    const item = tapiceriaItems[index];
    if (!item.id) return;
    await deleteTapiceriaItem(item.id);
    const updated = await getTapiceriaItems();
    setTapiceriaItemsState(updated);
    toast.success("Artículo eliminado");
  };

  const dayTitle = format(selectedDate, "EEEE d 'de' MMMM", { locale: es });

  const handleCopyReport = useCallback(async () => {
    // Save the report before copying
    await saveDailyReport(dateStr, appointments);
    
    const lines: string[] = [];
    lines.push(`📋 Reporte - ${dayTitle}`);
    lines.push("────────────────────────────────");
    if (appointments.length === 0) {
      lines.push("Sin servicios este día");
    } else {
      appointments.forEach((a) => {
        const end = calculateEndTime(a.time, a.durationHours);
        const icon = a.serviceType === "lavado" ? "🚗" : "🛋️";
        const detail = a.serviceType === "lavado"
          ? `Combo ${a.combo} × ${a.vehicleCount} vehículo(s)`
          : `Tapicería: ${a.tapiceriaItems?.map((i) => `${i.quantity}× ${i.type}`).join(", ")}`;
        lines.push(`🕐 ${a.time} → ${end}`);
        lines.push(`${icon} ${a.clientName}${a.manzana ? ` · Mz. ${a.manzana} Casa ${a.casa}` : ""}`);
        lines.push(`   ${detail}`);
        lines.push(`💰 ${a.price ? `${a.price} Bs` : "Sin precio"}`);
        lines.push("");
      });
      const total = appointments.reduce((sum, a) => sum + (a.price || 0), 0);
      lines.push("────────────────────────────────");
      lines.push(`💵 TOTAL DEL DÍA: ${total} Bs`);
    }
    navigator.clipboard.writeText(lines.join("\n")).then(() => {
      toast.success("✅ Reporte copiado y guardado");
    });
  }, [appointments, dayTitle, dateStr]);

  const statusColor = (status: string) => {
    switch (status) {
      case "pendiente": return "text-yellow-400 border-yellow-400/30";
      case "en_proceso": return "text-primary border-primary/30";
      case "completado": return "text-green-400 border-green-400/30";
      case "cancelado": return "text-destructive border-destructive/30";
      default: return "";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-primary">Cargando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="flex items-center gap-3 p-4 border-b border-border">
        <Link to="/"><ArrowLeft className="w-5 h-5 text-muted-foreground hover:text-primary" /></Link>
        <img src={logo} alt="" className="w-10 h-10 rounded-full object-cover" />
        <div>
          <h1 className="text-lg font-bold text-primary">Panel Administrador</h1>
          <p className="text-xs text-muted-foreground">Gorila Lava Todo</p>
        </div>
      </div>

      <div className="flex border-b border-border">
        {(["agenda", "resumen", "reportes", "horarios", "config"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 py-2.5 text-[10px] font-medium text-center transition-colors whitespace-nowrap ${tab === t ? "text-primary border-b-2 border-primary" : "text-muted-foreground"}`}
          >
            {t === "agenda" ? "Agenda" : t === "resumen" ? "Resumen" : t === "reportes" ? "Reporte" : t === "horarios" ? "Horarios" : "Config"}
          </button>
        ))}
      </div>

      {tab === "agenda" && (
        <>
          <CalendarStrip selectedDate={selectedDate} onSelectDate={setSelectedDate} days={14} />
          <h2 className="text-sm font-bold text-foreground px-4 mt-2">{dayTitle}</h2>
          <div className="px-2 mt-2 space-y-2 pb-8">
            {appointments.length === 0 ? (
              <div className="bg-card border border-border rounded-xl p-4 text-center text-muted-foreground text-sm">Sin servicios activos</div>
            ) : (
              appointments.map((a) => (
                <div key={a.id} className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-primary font-bold">{a.time}</span>
                        <span className="text-foreground font-medium text-sm">{a.clientName}</span>
                        <Badge variant="outline" className={`text-[10px] ${statusColor(a.status)}`}>{a.status.replace("_", " ")}</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1 space-y-0.5">
                        {a.manzana && <p>📍 Mz. {a.manzana} Casa {a.casa}</p>}
                        {a.phone && (
                          <p>📱 <a href={`https://wa.me/${a.phone.replace(/\D/g, "")}`} target="_blank" rel="noopener noreferrer" className="text-primary underline">{a.phone}</a></p>
                        )}
                        {a.serviceType === "lavado" && <p>🚗 Combo {a.combo} × {a.vehicleCount} vehículo(s) · {a.durationHours}h</p>}
                        {a.serviceType === "lavado" && a.vehicleSizeName && <p>📏 {a.vehicleSizeName}{a.vehicleSizePrice ? ` — ${a.vehicleSizePrice} Bs` : ""}</p>}
                        {a.serviceType === "tapiceria" && <p>🛋️ Tapicería: {a.tapiceriaItems?.map((i) => `${i.quantity}× ${i.type}`).join(", ")} · {a.durationHours}h</p>}
                        <p>💳 {a.paymentMethod === "qr" ? "Pago QR" : "Efectivo"}</p>
                        {a.price && <p className="text-primary font-medium">💰 {a.price} Bs</p>}
                      </div>
                    </div>
                    <div className="flex gap-1">
                      {a.status === "pendiente" && (
                        <Button size="icon" variant="ghost" onClick={() => handleStatus(a.id, "en_proceso")} className="text-primary h-8 w-8"><Play className="w-4 h-4" /></Button>
                      )}
                      {a.status === "en_proceso" && (
                        <Button size="icon" variant="ghost" onClick={() => handleStatus(a.id, "completado")} className="text-green-400 h-8 w-8"><CheckCircle className="w-4 h-4" /></Button>
                      )}
                      <Button size="icon" variant="ghost" onClick={() => handleDelete(a.id)} className="text-destructive h-8 w-8"><Trash2 className="w-3 h-3" /></Button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border">
                    <DollarSign className="w-4 h-4 text-primary flex-shrink-0" />
                    <Input 
                      type="number" 
                      placeholder="Precio Bs" 
                      value={priceInputs[a.id] || (a.price?.toString() || "")} 
                      onChange={(e) => setPriceInputs({ ...priceInputs, [a.id]: e.target.value })} 
                      className="bg-muted border-border h-8 text-xs w-24" 
                      min={0} 
                      disabled={a.status === "completado"}
                    />
                    <div className="flex items-center gap-2">
                      <Checkbox 
                        id={`paid-${a.id}`}
                        checked={a.status === "completado"}
                        onCheckedChange={() => handleMarkAsPaid(a.id, a.price)}
                        disabled={!a.price && !(priceInputs[a.id] && parseFloat(priceInputs[a.id]) > 0)}
                      />
                      <label htmlFor={`paid-${a.id}`} className="text-xs text-muted-foreground cursor-pointer">Pagado</label>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </>
      )}

      {tab === "reportes" && (
        <>
          <CalendarStrip selectedDate={selectedDate} onSelectDate={setSelectedDate} days={14} />
          <h2 className="text-sm font-bold text-foreground px-4 mt-2">{dayTitle}</h2>
          <div className="px-4 mt-2 space-y-2">
            <Button onClick={handleCopyReport} size="sm" variant="outline" className="w-full text-xs border-primary/50 text-primary hover:bg-primary/10">
              <Copy className="w-3 h-3 mr-2" /> Copiar y guardar reporte
            </Button>
            {/* Solo esta fila debe moverse/scroll (no todo el reporte) */}
            <div className="w-full overflow-hidden">
              <div className="w-full overflow-x-auto overscroll-x-contain">
                <div className="inline-flex gap-2 pr-2">
                  <Button
                    onClick={async () => {
                      await deleteReportsByPeriod("week");
                      toast.success("Reportes de más de 1 semana eliminados");
                    }}
                    size="sm"
                    variant="outline"
                    className="flex-none whitespace-nowrap text-[10px] border-destructive/50 text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-3 h-3 mr-1" /> Eliminar +1 semana
                  </Button>
                  <Button
                    onClick={async () => {
                      await deleteReportsByPeriod("month");
                      toast.success("Reportes de más de 1 mes eliminados");
                    }}
                    size="sm"
                    variant="outline"
                    className="flex-none whitespace-nowrap text-[10px] border-destructive/50 text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-3 h-3 mr-1" /> Eliminar +1 mes
                  </Button>
                  <Button
                    onClick={async () => {
                      await deleteReportsByPeriod("quarter");
                      toast.success("Reportes de más de 3 meses eliminados");
                    }}
                    size="sm"
                    variant="outline"
                    className="flex-none whitespace-nowrap text-[10px] border-destructive/50 text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-3 h-3 mr-1" /> Eliminar +3 meses
                  </Button>
                </div>
              </div>
            </div>
          </div>
          <div className="px-2 mt-3 space-y-2 pb-8">
            {appointments.length === 0 ? (
              <div className="bg-card border border-border rounded-xl p-4 text-center text-muted-foreground text-sm">Sin servicios este día</div>
            ) : (
              <>
                {appointments.map((a) => {
                  const endTime = calculateEndTime(a.time, a.durationHours);
                  return (
                    <div key={a.id} className="bg-card border border-border rounded-xl p-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-primary font-bold text-xs">{a.time} → {endTime}</span>
                        {a.price ? (
                          <span className="text-primary font-bold text-sm">{a.price} Bs</span>
                        ) : (
                          <span className="text-muted-foreground text-xs italic">Sin precio</span>
                        )}
                      </div>
                      <p className="text-sm font-medium text-foreground">
                        {a.serviceType === "lavado" ? "🚗" : "🛋️"} {a.clientName}
                      </p>
                      {a.manzana && (
                        <p className="text-xs text-muted-foreground">📍 Mz. {a.manzana} Casa {a.casa}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {a.serviceType === "lavado"
                          ? `Combo ${a.combo} × ${a.vehicleCount} vehículo(s)`
                          : `Tapicería: ${a.tapiceriaItems?.map((i) => `${i.quantity}× ${i.type}`).join(", ")}`}
                      </p>
                    </div>
                  );
                })}
                <div className="bg-primary/10 border border-primary/30 rounded-xl p-4 mt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-foreground font-bold text-sm">Total del día</span>
                    <span className="text-primary font-bold text-xl">
                      {appointments.reduce((sum, a) => sum + (a.price || 0), 0)} Bs
                    </span>
                  </div>
                  <div className="mt-2 space-y-1">
                    {appointments.filter((a) => a.price).map((a) => (
                      <div key={a.id} className="flex justify-between text-xs text-muted-foreground">
                        <span>{a.time} — {a.serviceType === "lavado" ? "🚗" : "🛋️"} {a.clientName}</span>
                        <span className="text-foreground">{a.price} Bs</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </>
      )}

      {tab === "resumen" && summary && (
        <>
          <CalendarStrip selectedDate={selectedDate} onSelectDate={setSelectedDate} days={14} />
          <h2 className="text-sm font-bold text-foreground px-4 mt-2">{dayTitle}</h2>
          <div className="px-2 mt-3 space-y-3 pb-8">
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-card border border-border rounded-xl p-3 text-center">
                <Clock className="w-5 h-5 text-primary mx-auto mb-1" />
                <p className="text-lg font-bold text-foreground">{summary.totalHours}h</p>
                <p className="text-[10px] text-muted-foreground">Horas trabajadas</p>
              </div>
              <div className="bg-card border border-border rounded-xl p-3 text-center">
                <CheckCircle className="w-5 h-5 text-green-400 mx-auto mb-1" />
                <p className="text-lg font-bold text-foreground">{summary.completed.length}</p>
                <p className="text-[10px] text-muted-foreground">Completados</p>
              </div>
              <div className="bg-card border border-border rounded-xl p-3 text-center">
                <TrendingUp className="w-5 h-5 text-primary mx-auto mb-1" />
                <p className="text-lg font-bold text-primary">{summary.totalEarnings} Bs</p>
                <p className="text-[10px] text-muted-foreground">Ganancia</p>
              </div>
            </div>

            {summary.firstTime && summary.lastTime && (
              <div className="bg-card border border-border rounded-xl p-4">
                <p className="text-xs text-muted-foreground mb-1">Jornada</p>
                <p className="text-foreground font-bold">{summary.firstTime} — {summary.lastTime}</p>
              </div>
            )}

            {summary.appts.length === 0 ? (
              <div className="bg-card border border-border rounded-xl p-4 text-center text-muted-foreground text-sm">Sin servicios este día</div>
            ) : (
              summary.appts.map((a: Appointment) => (
                <div key={a.id} className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-primary font-bold text-sm">{a.time}</span>
                        <span className="text-foreground text-sm">{a.clientName}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {a.manzana ? `Mz. ${a.manzana} Casa ${a.casa} · ` : ""}
                        {a.serviceType === "lavado" ? `Combo ${a.combo} × ${a.vehicleCount} vehículo(s)` : `Tapicería: ${a.tapiceriaItems?.map((i) => `${i.quantity}× ${i.type}`).join(", ")}`}
                        {` · ${a.durationHours}h`}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className={`text-[10px] ${statusColor(a.status)}`}>{a.status.replace("_", " ")}</Badge>
                      {a.price ? <p className="text-primary font-bold text-sm mt-1">{a.price} Bs</p> : <p className="text-muted-foreground text-[10px] mt-1">Sin precio</p>}
                    </div>
                  </div>
                </div>
              ))
            )}

            {summary.completed.length > 0 && (
              <div className="bg-primary/10 border border-primary/30 rounded-xl p-4">
                <div className="flex items-center justify-between">
                  <span className="text-foreground font-bold">Total del día</span>
                  <span className="text-primary font-bold text-xl">{summary.totalEarnings} Bs</span>
                </div>
                <div className="mt-2 space-y-1">
                  {summary.completed.filter((a: Appointment) => a.price).map((a: Appointment) => (
                    <div key={a.id} className="flex justify-between text-xs text-muted-foreground">
                      <span>{a.time} — {a.clientName}</span>
                      <span className="text-foreground">{a.price} Bs</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </>
      )}

      {tab === "horarios" && (
        <div className="p-4 space-y-3">
          {/* Break config */}
          <div className="bg-card border border-primary/30 rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-primary">☕ Descanso</span>
              <Switch checked={adminConfig.breakEnabled} onCheckedChange={async (v) => {
                const updated = { ...adminConfig, breakEnabled: v };
                setAdminConfig(updated);
                await saveAdminConfig(updated);
                toast.success(v ? "Descanso activado" : "Descanso desactivado");
              }} />
            </div>
            {adminConfig.breakEnabled && (
              <div className="flex items-center gap-2 mt-2">
                <Input type="time" value={adminConfig.breakStart} onChange={async (e) => {
                  const updated = { ...adminConfig, breakStart: e.target.value };
                  setAdminConfig(updated);
                  await saveAdminConfig(updated);
                }} className="bg-muted border-border w-28 text-xs" />
                <span className="text-muted-foreground text-xs">a</span>
                <Input type="time" value={adminConfig.breakEnd} onChange={async (e) => {
                  const updated = { ...adminConfig, breakEnd: e.target.value };
                  setAdminConfig(updated);
                  await saveAdminConfig(updated);
                }} className="bg-muted border-border w-28 text-xs" />
              </div>
            )}
          </div>

          {DAY_NAMES.map((name, i) => {
            const day = schedule[i];
            if (!day) return null;
            return (
              <div key={i} className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">{name}</span>
                  <Switch checked={day.enabled} onCheckedChange={(v) => handleScheduleChange(i, "enabled", v)} />
                </div>
                {day.enabled && (
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <Input type="time" value={day.start} onChange={(e) => handleScheduleChange(i, "start", e.target.value)} className="bg-muted border-border w-28 text-xs" />
                    <span className="text-muted-foreground text-xs">a</span>
                    <Input type="time" value={day.end} onChange={(e) => handleScheduleChange(i, "end", e.target.value)} className="bg-muted border-border w-28 text-xs" />
                    <span className="text-muted-foreground text-xs">cada</span>
                    <Input type="number" value={day.interval} onChange={(e) => handleScheduleChange(i, "interval", parseInt(e.target.value) || 30)} className="bg-muted border-border w-16 text-xs" min={15} max={120} />
                    <span className="text-muted-foreground text-xs">min</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {tab === "config" && (
        <div className="p-4 space-y-4">
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <Phone className="w-4 h-4 text-primary" />
              <span className="text-sm font-bold text-foreground">Número de WhatsApp</span>
            </div>
            <Input value={adminConfig.whatsappNumber} onChange={(e) => setAdminConfig({ ...adminConfig, whatsappNumber: e.target.value })} placeholder="5919991234567" className="bg-muted border-border mb-2" maxLength={20} />
            <p className="text-[10px] text-muted-foreground mb-2">Incluye código de país. Ej: 5919991234567</p>
            <Button onClick={handleWhatsappSave} size="sm" className="bg-primary text-primary-foreground font-bold">Guardar</Button>
          </div>

          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <Upload className="w-4 h-4 text-primary" />
              <span className="text-sm font-bold text-foreground">Imagen QR de Pago</span>
            </div>
            {adminConfig.qrImageBase64 && <img src={adminConfig.qrImageBase64} alt="QR" className="w-40 h-40 mx-auto rounded-xl object-contain bg-white p-2 mb-3" />}
            <label className="block">
              <input type="file" accept="image/*" onChange={handleQRUpload} className="hidden" />
              <div className="bg-muted border border-dashed border-border rounded-xl p-4 text-center cursor-pointer hover:border-primary transition-colors">
                <Upload className="w-6 h-6 text-muted-foreground mx-auto mb-1" />
                <p className="text-xs text-muted-foreground">Toca para subir imagen QR</p>
              </div>
            </label>
          </div>

          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Pencil className="w-4 h-4 text-primary" />
                <span className="text-sm font-bold text-foreground">Artículos de Tapicería</span>
              </div>
              <Button size="sm" variant="ghost" onClick={() => { setTapiceriaForm({ type: "", hours: "" }); setShowAddTapiceria(true); }} className="text-primary h-8">
                <Plus className="w-4 h-4 mr-1" /> Agregar
              </Button>
            </div>
            <div className="space-y-2">
              {tapiceriaItems.map((item, idx) => (
                <div key={item.id || idx} className="flex items-center justify-between bg-muted rounded-xl p-3">
                  {editingTapiceria === idx ? (
                    <div className="flex-1 flex items-center gap-2">
                      <Input value={tapiceriaForm.type} onChange={(e) => setTapiceriaForm({ ...tapiceriaForm, type: e.target.value })} className="bg-card border-border h-8 text-xs flex-1" placeholder="Nombre" />
                      <Input type="number" value={tapiceriaForm.hours} onChange={(e) => setTapiceriaForm({ ...tapiceriaForm, hours: e.target.value })} className="bg-card border-border h-8 text-xs w-16" placeholder="Horas" step={0.5} min={0.5} />
                      <Button size="sm" onClick={() => handleSaveTapiceriaItem(idx)} className="bg-primary text-primary-foreground h-8 text-xs px-2">✓</Button>
                      <Button size="sm" variant="ghost" onClick={() => setEditingTapiceria(null)} className="h-8 text-xs px-2">✕</Button>
                    </div>
                  ) : (
                    <>
                      <div>
                        <p className="text-sm font-medium text-foreground">{item.type}</p>
                        <p className="text-[10px] text-muted-foreground">{item.hours}h por unidad</p>
                      </div>
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" onClick={() => { setEditingTapiceria(idx); setTapiceriaForm({ type: item.type, hours: String(item.hours) }); }} className="h-8 w-8 text-primary">
                          <Pencil className="w-3 h-3" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => handleDeleteTapiceriaItem(idx)} className="h-8 w-8 text-destructive">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Vehicle Sizes Management */}
          <div className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Car className="w-4 h-4 text-primary" />
                <span className="text-sm font-bold text-foreground">Tamaños de Vehículo</span>
              </div>
              <Button size="sm" variant="ghost" onClick={() => { setVehicleSizeForm({ name: "", price: "" }); setShowAddVehicleSize(true); }} className="text-primary h-8">
                <Plus className="w-4 h-4 mr-1" /> Agregar
              </Button>
            </div>
            <div className="space-y-2">
              {vehicleSizesState.map((vs, idx) => (
                <div key={vs.id} className="flex items-center justify-between bg-muted rounded-xl p-3">
                  {editingVehicleSize === idx ? (
                    <div className="flex-1 flex items-center gap-2">
                      <Input value={vehicleSizeForm.name} onChange={(e) => setVehicleSizeForm({ ...vehicleSizeForm, name: e.target.value })} className="bg-card border-border h-8 text-xs flex-1" placeholder="Nombre" />
                      <Input type="number" value={vehicleSizeForm.price} onChange={(e) => setVehicleSizeForm({ ...vehicleSizeForm, price: e.target.value })} className="bg-card border-border h-8 text-xs w-20" placeholder="Precio" min={0} />
                      <Button size="sm" onClick={async () => {
                        await updateVehicleSize(vs.id, vehicleSizeForm.name, parseFloat(vehicleSizeForm.price) || 0);
                        setVehicleSizesState(await getVehicleSizes());
                        setEditingVehicleSize(null);
                        toast.success("Tamaño actualizado");
                      }} className="bg-primary text-primary-foreground h-8 text-xs px-2">✓</Button>
                      <Button size="sm" variant="ghost" onClick={() => setEditingVehicleSize(null)} className="h-8 text-xs px-2">✕</Button>
                    </div>
                  ) : (
                    <>
                      <div>
                        <p className="text-sm font-medium text-foreground">{vs.name}</p>
                        <p className="text-[10px] text-primary font-medium">{vs.price} Bs</p>
                      </div>
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" onClick={() => { setEditingVehicleSize(idx); setVehicleSizeForm({ name: vs.name, price: String(vs.price) }); }} className="h-8 w-8 text-primary">
                          <Pencil className="w-3 h-3" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={async () => {
                          await deleteVehicleSize(vs.id);
                          setVehicleSizesState(await getVehicleSizes());
                          toast.success("Tamaño eliminado");
                        }} className="h-8 w-8 text-destructive">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <Dialog open={showAddTapiceria} onOpenChange={setShowAddTapiceria}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle className="text-primary">Agregar Artículo</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-muted-foreground">Nombre del artículo</label>
              <Input value={tapiceriaForm.type} onChange={(e) => setTapiceriaForm({ ...tapiceriaForm, type: e.target.value })} placeholder="Ej: Colchón King" className="bg-muted border-border" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Horas por unidad</label>
              <Input type="number" value={tapiceriaForm.hours} onChange={(e) => setTapiceriaForm({ ...tapiceriaForm, hours: e.target.value })} placeholder="Ej: 2.5" className="bg-muted border-border" step={0.5} min={0.5} />
            </div>
            <Button onClick={handleAddTapiceriaItem} className="w-full bg-primary text-primary-foreground font-bold">Agregar</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showAddVehicleSize} onOpenChange={setShowAddVehicleSize}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle className="text-primary">Agregar Tamaño de Vehículo</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-muted-foreground">Nombre (ej: Auto Pequeño)</label>
              <Input value={vehicleSizeForm.name} onChange={(e) => setVehicleSizeForm({ ...vehicleSizeForm, name: e.target.value })} placeholder="Ej: Auto Mediano" className="bg-muted border-border" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Precio (Bs)</label>
              <Input type="number" value={vehicleSizeForm.price} onChange={(e) => setVehicleSizeForm({ ...vehicleSizeForm, price: e.target.value })} placeholder="Ej: 70" className="bg-muted border-border" min={0} />
            </div>
            <Button onClick={async () => {
              if (!vehicleSizeForm.name.trim()) { toast.error("Ingresa un nombre"); return; }
              await addVehicleSize(vehicleSizeForm.name.trim(), parseFloat(vehicleSizeForm.price) || 0, vehicleSizesState.length + 1);
              setVehicleSizesState(await getVehicleSizes());
              setShowAddVehicleSize(false);
              setVehicleSizeForm({ name: "", price: "" });
              toast.success("Tamaño agregado");
            }} className="w-full bg-primary text-primary-foreground font-bold">Agregar</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminDashboard;
