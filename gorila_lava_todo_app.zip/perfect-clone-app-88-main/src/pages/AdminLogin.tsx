import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ADMIN_CODE } from "@/lib/store";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Lock } from "lucide-react";
import { toast } from "sonner";
import logo from "@/assets/logo.jpg";

const AdminLogin = () => {
  const [code, setCode] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code === ADMIN_CODE) {
      sessionStorage.setItem("gorila_admin", "true");
      navigate("/admin/dashboard");
    } else {
      toast.error("Código incorrecto");
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <form onSubmit={handleSubmit} className="bg-card border border-border rounded-2xl p-8 w-full max-w-sm text-center space-y-6">
        <img src={logo} alt="Gorila Lava Todo" className="w-20 h-20 mx-auto rounded-full object-cover" />
        <Lock className="w-12 h-12 text-primary mx-auto" />
        <div>
          <h2 className="text-xl font-bold text-primary">Panel Administrador</h2>
          <p className="text-muted-foreground text-sm mt-1">Ingresa el código de acceso</p>
        </div>
        <Input
          type="password"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="Código de acceso"
          className="bg-muted border-border text-center text-lg tracking-[0.3em]"
          maxLength={6}
        />
        <Button type="submit" className="w-full bg-primary text-primary-foreground font-bold">
          Ingresar
        </Button>
      </form>
    </div>
  );
};

export default AdminLogin;
