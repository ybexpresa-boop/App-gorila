import { useState, useEffect } from "react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import logo from "@/assets/logo.jpg";
import CalendarStrip from "@/components/CalendarStrip";
import TimeSlotsGrid from "@/components/TimeSlotsGrid";
import { Link } from "react-router-dom";
import whatsappIcon from "@/assets/whatsapp-icon.jpeg";
import { getAdminConfig, type AdminConfig } from "@/lib/store";

const Index = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [adminConfig, setAdminConfig] = useState<AdminConfig>({ whatsappNumber: "", qrImageBase64: "", breakEnabled: true, breakStart: "12:00", breakEnd: "12:30" });
  const dayTitle = format(selectedDate, "EEEE d 'de' MMMM", { locale: es });

  useEffect(() => {
    getAdminConfig().then(setAdminConfig);
  }, []);

  const whatsappUrl = adminConfig.whatsappNumber
    ? `https://wa.me/${adminConfig.whatsappNumber.replace(/\D/g, "")}`
    : "#";

  return (
    <div className="min-h-screen bg-background">
      <div className="text-center pt-6 pb-2 px-4">
        <img src={logo} alt="Gorila Lava Todo" className="w-24 h-24 mx-auto rounded-full object-cover border-2 border-primary/30" />
        <h1 className="text-2xl font-bold text-primary mt-3 tracking-wide">GORILA LAVA TODO</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Servicio de lavado de tapicería y automóviles a domicilio</p>
      </div>

      <div className="mx-2 mt-3 bg-card border border-primary/20 rounded-xl p-3 flex items-center gap-3">
        <img src={whatsappIcon} alt="WhatsApp" className="w-5 h-5 flex-shrink-0 rounded" />
        <div className="flex-1">
          <p className="text-sm text-foreground font-medium">¿Necesitas un servicio?</p>
          <p className="text-xs text-muted-foreground">Contáctanos por WhatsApp para más información</p>
        </div>
        <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="bg-[#25D366] text-white text-xs font-bold px-3 py-1.5 rounded-lg hover:opacity-90 transition-opacity">
          WhatsApp
        </a>
      </div>

      <CalendarStrip selectedDate={selectedDate} onSelectDate={setSelectedDate} />
      <h2 className="text-base font-bold text-foreground px-4 mt-2">{dayTitle}</h2>
      <TimeSlotsGrid selectedDate={selectedDate} />

      <div className="px-4 py-6">
        <Link to="/admin" className="text-xs text-muted-foreground hover:text-primary transition-colors">
          Panel Administrador
        </Link>
      </div>

      <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="fixed bottom-6 right-6 w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform z-50 overflow-hidden">
        <img src={whatsappIcon} alt="WhatsApp" className="w-full h-full object-cover" />
      </a>
    </div>
  );
};

export default Index;
