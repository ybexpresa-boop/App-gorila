export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      admin_config: {
        Row: {
          break_enabled: boolean
          break_end: string
          break_start: string
          id: number
          qr_image_base64: string | null
          whatsapp_number: string | null
        }
        Insert: {
          break_enabled?: boolean
          break_end?: string
          break_start?: string
          id?: number
          qr_image_base64?: string | null
          whatsapp_number?: string | null
        }
        Update: {
          break_enabled?: boolean
          break_end?: string
          break_start?: string
          id?: number
          qr_image_base64?: string | null
          whatsapp_number?: string | null
        }
        Relationships: []
      }
      appointments: {
        Row: {
          casa: string | null
          client_name: string
          combo: number | null
          created_at: string
          date: string
          duration_hours: number
          id: string
          manzana: string | null
          payment_method: string
          phone: string | null
          price: number | null
          service_type: string
          status: string
          tapiceria_items: Json | null
          time: string
          vehicle_count: number | null
          vehicle_size_name: string | null
          vehicle_size_price: number | null
        }
        Insert: {
          casa?: string | null
          client_name: string
          combo?: number | null
          created_at?: string
          date: string
          duration_hours: number
          id?: string
          manzana?: string | null
          payment_method: string
          phone?: string | null
          price?: number | null
          service_type: string
          status?: string
          tapiceria_items?: Json | null
          time: string
          vehicle_count?: number | null
          vehicle_size_name?: string | null
          vehicle_size_price?: number | null
        }
        Update: {
          casa?: string | null
          client_name?: string
          combo?: number | null
          created_at?: string
          date?: string
          duration_hours?: number
          id?: string
          manzana?: string | null
          payment_method?: string
          phone?: string | null
          price?: number | null
          service_type?: string
          status?: string
          tapiceria_items?: Json | null
          time?: string
          vehicle_count?: number | null
          vehicle_size_name?: string | null
          vehicle_size_price?: number | null
        }
        Relationships: []
      }
      daily_reports: {
        Row: {
          appointments_data: Json
          created_at: string
          id: string
          report_date: string
          total_earnings: number
          total_services: number
        }
        Insert: {
          appointments_data?: Json
          created_at?: string
          id?: string
          report_date: string
          total_earnings?: number
          total_services?: number
        }
        Update: {
          appointments_data?: Json
          created_at?: string
          id?: string
          report_date?: string
          total_earnings?: number
          total_services?: number
        }
        Relationships: []
      }
      tapiceria_items: {
        Row: {
          hours: number
          id: number
          type: string
        }
        Insert: {
          hours?: number
          id?: number
          type: string
        }
        Update: {
          hours?: number
          id?: number
          type?: string
        }
        Relationships: []
      }
      vehicle_sizes: {
        Row: {
          id: number
          name: string
          price: number
          sort_order: number
        }
        Insert: {
          id?: number
          name: string
          price?: number
          sort_order?: number
        }
        Update: {
          id?: number
          name?: string
          price?: number
          sort_order?: number
        }
        Relationships: []
      }
      work_schedule: {
        Row: {
          day_of_week: number
          enabled: boolean
          end_time: string
          interval_minutes: number
          start_time: string
        }
        Insert: {
          day_of_week: number
          enabled?: boolean
          end_time?: string
          interval_minutes?: number
          start_time?: string
        }
        Update: {
          day_of_week?: number
          enabled?: boolean
          end_time?: string
          interval_minutes?: number
          start_time?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
