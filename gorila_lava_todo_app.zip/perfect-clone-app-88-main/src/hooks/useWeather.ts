import { useState, useEffect } from "react";

export interface WeatherDay {
  date: string;
  tempMax: number;
  tempMin: number;
  description: string;
  emoji: string;
  humidity: number;
  windSpeed: number;
  precipitation: number;
  weatherCode: number;
}

const WMO_CODES: Record<number, { desc: string; emoji: string }> = {
  0: { desc: "Despejado", emoji: "☀️" },
  1: { desc: "Mayormente despejado", emoji: "🌤️" },
  2: { desc: "Parcialmente nublado", emoji: "⛅" },
  3: { desc: "Nublado", emoji: "☁️" },
  45: { desc: "Niebla", emoji: "🌫️" },
  48: { desc: "Niebla helada", emoji: "🌫️" },
  51: { desc: "Llovizna ligera", emoji: "🌦️" },
  53: { desc: "Llovizna moderada", emoji: "🌦️" },
  55: { desc: "Llovizna densa", emoji: "🌧️" },
  61: { desc: "Lluvia ligera", emoji: "🌧️" },
  63: { desc: "Lluvia moderada", emoji: "🌧️" },
  65: { desc: "Lluvia fuerte", emoji: "🌧️" },
  71: { desc: "Nieve ligera", emoji: "🌨️" },
  73: { desc: "Nieve moderada", emoji: "🌨️" },
  75: { desc: "Nieve fuerte", emoji: "🌨️" },
  80: { desc: "Chubascos ligeros", emoji: "🌧️" },
  81: { desc: "Chubascos moderados", emoji: "🌧️" },
  82: { desc: "Chubascos violentos", emoji: "⛈️" },
  95: { desc: "Tormenta", emoji: "⛈️" },
  96: { desc: "Tormenta con granizo", emoji: "⛈️" },
  99: { desc: "Tormenta con granizo fuerte", emoji: "⛈️" },
};

function getWeatherInfo(code: number) {
  return WMO_CODES[code] || { desc: "Desconocido", emoji: "❓" };
}

export function isGoodForWash(code: number, precipitation: number): boolean {
  // Good if no rain/drizzle and low precipitation
  return code <= 3 && precipitation < 1;
}

export function useWeather(lat = -17.78, lon = -63.18) {
  const [forecast, setForecast] = useState<WeatherDay[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const res = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,relative_humidity_2m_max&timezone=auto&forecast_days=7`
        );
        const data = await res.json();
        const days: WeatherDay[] = data.daily.time.map((date: string, i: number) => {
          const code = data.daily.weather_code[i];
          const info = getWeatherInfo(code);
          return {
            date,
            tempMax: Math.round(data.daily.temperature_2m_max[i]),
            tempMin: Math.round(data.daily.temperature_2m_min[i]),
            description: info.desc,
            emoji: info.emoji,
            humidity: data.daily.relative_humidity_2m_max[i],
            windSpeed: Math.round(data.daily.wind_speed_10m_max[i]),
            precipitation: data.daily.precipitation_sum[i],
            weatherCode: code,
          };
        });
        setForecast(days);
      } catch (e) {
        console.error("Weather fetch failed:", e);
      } finally {
        setLoading(false);
      }
    };
    fetchWeather();
  }, [lat, lon]);

  return { forecast, loading };
}
