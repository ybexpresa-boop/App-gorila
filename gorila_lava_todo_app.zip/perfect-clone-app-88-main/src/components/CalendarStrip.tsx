import { useMemo } from "react";
import { format, addDays, isSameDay } from "date-fns";
import { es } from "date-fns/locale";

interface CalendarStripProps {
  selectedDate: Date;
  onSelectDate: (date: Date) => void;
  days?: number;
}

const CalendarStrip = ({ selectedDate, onSelectDate, days = 7 }: CalendarStripProps) => {
  const dates = useMemo(() => {
    const today = new Date();
    return Array.from({ length: days }, (_, i) => addDays(today, i));
  }, [days]);

  return (
    <div className="flex gap-1 overflow-x-auto py-3 px-2 scrollbar-hide">
      {dates.map((date) => {
        const isSelected = isSameDay(date, selectedDate);
        const dayName = format(date, "EEE", { locale: es }).toUpperCase();
        const dayNum = format(date, "d");
        const month = format(date, "MMM", { locale: es });

        return (
          <button
            key={date.toISOString()}
            onClick={() => onSelectDate(date)}
            className={`flex flex-col items-center min-w-[48px] px-2 py-1.5 rounded-lg transition-all text-xs ${
              isSelected
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-muted"
            }`}
          >
            <span className="text-[10px] font-medium">{dayName}</span>
            <span className="text-lg font-bold leading-tight">{dayNum}</span>
            <span className="text-[10px]">{month}</span>
          </button>
        );
      })}
    </div>
  );
};

export default CalendarStrip;
