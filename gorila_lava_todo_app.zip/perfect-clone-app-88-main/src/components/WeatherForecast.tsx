import { useWeather, isGoodForWash, type WeatherDay } from "@/hooks/useWeather";
import { format, parseISO } from "date-fns";
import { es } from "date-fns/locale";

interface WeatherForecastProps {
  selectedDate: Date;
}

const WeatherForecast = ({ selectedDate }: WeatherForecastProps) => {
  const { forecast, loading } = useWeather();

  if (loading) {
    return (
      <div className="bg-card rounded-xl p-4 mt-4 animate-pulse">
        <div className="h-20 bg-muted rounded" />
      </div>
    );
  }

  if (forecast.length === 0) return null;

  const dateStr = format(selectedDate, "yyyy-MM-dd");
  const todayWeather = forecast.find((f) => f.date === dateStr) || forecast[0];
  const dayName = format(selectedDate, "EEEE", { locale: es });
  const good = isGoodForWash(todayWeather.weatherCode, todayWeather.precipitation);

  return (
    <div className="mt-4 space-y-3 px-2">
      {/* Main forecast card */}
      <div className="bg-card border border-border rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wider">
            <span>⚙️</span>
            <span>Pronóstico · {dayName}</span>
          </div>
          <div
            className={`text-xs font-bold px-3 py-1 rounded-full ${
              good
                ? "bg-primary/20 text-primary"
                : "bg-destructive/20 text-destructive"
            }`}
          >
            {good ? "✓ Recomendado" : "✗ No recomendado"}
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <span className="text-4xl">{todayWeather.emoji}</span>
            <div>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold text-foreground">{todayWeather.tempMax}°</span>
                <span className="text-lg text-muted-foreground">/{todayWeather.tempMin}°</span>
              </div>
              <p className="text-sm text-muted-foreground">{todayWeather.description}</p>
            </div>
          </div>

          <div className="space-y-1 text-xs text-muted-foreground">
            <p>💧 Humedad <span className="text-foreground font-medium">{todayWeather.humidity}%</span></p>
            <p>💨 Viento <span className="text-foreground font-medium">{todayWeather.windSpeed} km/h</span></p>
            <p>🌧️ Lluvia <span className="text-foreground font-medium">{todayWeather.precipitation} mm</span></p>
          </div>
        </div>
      </div>

      {/* 7-day mini forecast */}
      <div className="flex gap-1 overflow-x-auto">
        {forecast.map((day) => {
          const d = parseISO(day.date);
          const name = format(d, "EEE", { locale: es }).toUpperCase();
          return (
            <div
              key={day.date}
              className="flex-1 min-w-[65px] bg-card border border-border rounded-xl p-2 text-center"
            >
              <p className="text-[10px] text-muted-foreground font-medium">{name}</p>
              <p className="text-lg my-0.5">{day.emoji}</p>
              <p className="text-xs">
                <span className="text-foreground font-medium">{day.tempMax}°</span>
                <span className="text-muted-foreground">{day.tempMin}°</span>
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default WeatherForecast;
