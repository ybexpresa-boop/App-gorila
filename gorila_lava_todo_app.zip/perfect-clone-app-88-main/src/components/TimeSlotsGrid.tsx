import { useState, useEffect, useCallback } from "react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  addAppointment, getTimeSlots, getOccupiedSlots, canFitAppointment,
  COMBO_DURATIONS, COMBO_SERVICES, getTapiceriaItems, getBreakSlots,
  getAppointmentsByDate, getVehicleSizes, getAdminConfig,
  type VehicleCombo, type ServiceType, type PaymentMethod,
  type TapiceriaItemConfig, type Appointment, type VehicleSize, type AdminConfig,
  cancelAppointmentByName,
} from "@/lib/store";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Car, Sofa, CreditCard, QrCode, Check, X, ChevronRight, Minus, Plus, MessageCircle, Download } from "lucide-react";

interface TimeSlotsGridProps {
  selectedDate: Date;
}

const TimeSlotsGrid = ({ selectedDate }: TimeSlotsGridProps) => {
  const [bookingSlot, setBookingSlot] = useState<string | null>(null);
  // Steps: 1=service type, 2=combo/tapiceria, 3=vehicle size (lavado only), 4=datos, 5=payment
  const [step, setStep] = useState(1);
  const [serviceType, setServiceType] = useState<ServiceType>("lavado");
  const [combo, setCombo] = useState<VehicleCombo>(1);
  const [vehicleCount, setVehicleCount] = useState(1);
  const [tapiceriaItems, setTapiceriaItems] = useState<{ type: string; quantity: number }[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("efectivo");
  const [selectedVehicleSize, setSelectedVehicleSize] = useState<VehicleSize | null>(null);
  const [showCancel, setShowCancel] = useState(false);
  const [cancelName, setCancelName] = useState("");
  const [form, setForm] = useState({ clientName: "", manzana: "", casa: "", phone: "" });

  const [slots, setSlots] = useState<string[]>([]);
  const [occupied, setOccupied] = useState<Set<string>>(new Set());
  const [breakSlots, setBreakSlots] = useState<Set<string>>(new Set());
  const [tapiceriaConfig, setTapiceriaConfig] = useState<TapiceriaItemConfig[]>([]);
  const [vehicleSizes, setVehicleSizes] = useState<VehicleSize[]>([]);
  const [adminConfig, setAdminConfigState] = useState<AdminConfig | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  const dateStr = format(selectedDate, "yyyy-MM-dd");

  // Map each slot to its appointment
  const slotAppointmentMap = new Map<string, Appointment>();
  for (const appt of appointments.filter(a => a.status !== "cancelado")) {
    const startIdx = slots.indexOf(appt.time);
    if (startIdx === -1) continue;
    const slotInterval = slots.length >= 2
      ? (parseInt(slots[1].split(":")[0]) * 60 + parseInt(slots[1].split(":")[1])) - (parseInt(slots[0].split(":")[0]) * 60 + parseInt(slots[0].split(":")[1]))
      : 60;
    const slotsNeeded = Math.max(1, Math.ceil((appt.durationHours * 60) / slotInterval));
    for (let i = 0; i < slotsNeeded && startIdx + i < slots.length; i++) {
      slotAppointmentMap.set(slots[startIdx + i], appt);
    }
  }

  const calculateEndTime = (time: string, hours: number) => {
    const [h, m] = time.split(":").map(Number);
    const total = h * 60 + m + Math.round(hours * 60);
    return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
  };

  const loadData = useCallback(async () => {
    setLoading(true);
    const [s, tc, appts, vs, ac] = await Promise.all([
      getTimeSlots(selectedDate),
      getTapiceriaItems(),
      getAppointmentsByDate(dateStr),
      getVehicleSizes(),
      getAdminConfig(),
    ]);
    setSlots(s);
    setTapiceriaConfig(tc);
    setAppointments(appts);
    setVehicleSizes(vs);
    setAdminConfigState(ac);
    const [bs, occ] = await Promise.all([getBreakSlots(s, ac), getOccupiedSlots(dateStr, s)]);
    setBreakSlots(bs);
    setOccupied(occ);
    setLoading(false);
  }, [selectedDate, dateStr]);

  useEffect(() => { loadData(); }, [loadData]);

  const calcDuration = (): number => {
    if (serviceType === "lavado") return COMBO_DURATIONS[combo] * vehicleCount;
    return tapiceriaItems.reduce((total, item) => {
      const info = tapiceriaConfig.find((t) => t.type === item.type);
      return total + (info?.hours || 2) * item.quantity;
    }, 0);
  };

  const duration = calcDuration();

  const handleSlotClick = (time: string) => {
    setBookingSlot(time);
    setStep(1);
    setServiceType("lavado");
    setCombo(1);
    setVehicleCount(1);
    setTapiceriaItems([]);
    setPaymentMethod("efectivo");
    setSelectedVehicleSize(null);
    setForm({ clientName: "", manzana: "", casa: "", phone: "" });
  };

  const handleBook = async () => {
    if (!bookingSlot || !form.clientName.trim()) {
      toast.error("Ingresa tu nombre");
      return;
    }
    if (serviceType === "tapiceria" && tapiceriaItems.length === 0) {
      toast.error("Selecciona al menos un artículo");
      return;
    }
    if (serviceType === "lavado" && !selectedVehicleSize) {
      toast.error("Selecciona un tamaño de vehículo");
      return;
    }
    const fits = await canFitAppointment(dateStr, bookingSlot, duration, slots);
    if (!fits) {
      toast.error("No hay suficiente espacio en el horario para este servicio");
      return;
    }

    await addAppointment({
      date: dateStr,
      time: bookingSlot,
      clientName: form.clientName.trim(),
      manzana: form.manzana.trim(),
      casa: form.casa.trim(),
      phone: form.phone.trim(),
      serviceType,
      vehicleCount: serviceType === "lavado" ? vehicleCount : undefined,
      combo: serviceType === "lavado" ? combo : undefined,
      tapiceriaItems: serviceType === "tapiceria" ? tapiceriaItems : undefined,
      paymentMethod,
      durationHours: duration,
      vehicleSizeName: selectedVehicleSize?.name,
      vehicleSizePrice: selectedVehicleSize?.price,
    });

    setBookingSlot(null);
    await loadData();
    toast.success("¡Servicio agendado exitosamente!");
  };

  const handleCancel = async () => {
    if (!cancelName.trim()) {
      toast.error("Ingresa tu nombre");
      return;
    }
    const success = await cancelAppointmentByName(cancelName.trim(), dateStr);
    if (success) {
      toast.success("Servicio cancelado. El horario está libre.");
      setCancelName("");
      setShowCancel(false);
      await loadData();
    } else {
      toast.error("No se encontró un servicio activo con ese nombre para hoy.");
    }
  };

  const updateTapiceria = (type: string, delta: number) => {
    setTapiceriaItems((prev) => {
      const existing = prev.find((i) => i.type === type);
      if (existing) {
        const newQty = existing.quantity + delta;
        if (newQty <= 0) return prev.filter((i) => i.type !== type);
        return prev.map((i) => (i.type === type ? { ...i, quantity: newQty } : i));
      }
      if (delta > 0) return [...prev, { type, quantity: 1 }];
      return prev;
    });
  };

  const handleDownloadQR = () => {
    if (!adminConfig?.qrImageBase64) return;
    const link = document.createElement("a");
    link.href = adminConfig.qrImageBase64;
    link.download = "qr-pago.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Step navigation helpers for lavado: 1→2→3→4→5
  // For tapiceria: 1→2→4→5
  const getStepTitle = () => {
    if (step === 1) return "Tipo de Servicio";
    if (step === 2 && serviceType === "lavado") return "Selecciona Combo";
    if (step === 2 && serviceType === "tapiceria") return "Selecciona Artículos";
    if (step === 3) return "Tamaño de Vehículo";
    if (step === 4) return "Tus Datos";
    if (step === 5) return "Método de Pago";
    return "";
  };

  const goBack = () => {
    if (step === 4 && serviceType === "tapiceria") setStep(2);
    else setStep(step - 1);
  };

  if (loading) {
    return (
      <div className="mt-2 px-2">
        <div className="grid grid-cols-3 gap-2">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="rounded-xl p-3 bg-card border border-border animate-pulse h-16" />
          ))}
        </div>
      </div>
    );
  }

  if (slots.length === 0) {
    return (
      <div className="bg-card border border-border rounded-xl p-6 text-center text-muted-foreground mt-2 mx-2">
        No hay horarios disponibles para este día
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-3 gap-2 mt-2 px-2">
        {slots.filter((time) => !breakSlots.has(time)).map((time) => {
          const taken = occupied.has(time);
          const appt = slotAppointmentMap.get(time);
          const isStartSlot = appt && appt.time === time;
          return (
            <button
              key={time}
              disabled={taken}
              onClick={() => handleSlotClick(time)}
              className={`rounded-xl p-3 text-center transition-all border ${
                taken
                  ? "bg-muted border-border opacity-50 cursor-not-allowed"
                  : "bg-card border-primary/20 hover:border-primary hover:shadow-[0_0_12px_hsl(var(--primary)/0.3)] cursor-pointer"
              }`}
            >
              <p className={`text-base font-bold ${taken ? "text-muted-foreground" : "text-primary"}`}>{time}</p>
              {taken && appt ? (
                <div>
                  <p className="text-[10px] text-destructive font-medium truncate">{appt.clientName}</p>
                  {isStartSlot && (
                    <p className="text-[9px] text-muted-foreground">{appt.time}→{calculateEndTime(appt.time, appt.durationHours)}</p>
                  )}
                </div>
              ) : taken ? (
                <p className="text-[10px] text-destructive">Ocupado</p>
              ) : (
                <p className="text-[10px] text-primary/70">Disponible</p>
              )}
            </button>
          );
        })}
      </div>

      <div className="mt-4 px-2">
        <button
          onClick={() => setShowCancel(true)}
          className="w-full bg-card border border-border rounded-xl p-3 text-center text-muted-foreground text-sm hover:border-destructive/50 transition-colors"
        >
          ¿Necesitas cancelar tu servicio?
        </button>
      </div>

      {/* Booking dialog */}
      <Dialog open={!!bookingSlot} onOpenChange={() => setBookingSlot(null)}>
        <DialogContent className="bg-card border-border max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-primary text-lg">{getStepTitle()}</DialogTitle>
            <p className="text-xs text-muted-foreground">
              {bookingSlot} · {format(selectedDate, "d 'de' MMMM", { locale: es })}
            </p>
          </DialogHeader>

          {step === 1 && (
            <div className="space-y-3 mt-2">
              <button
                onClick={() => { setServiceType("lavado"); setStep(2); }}
                className="w-full bg-muted border border-border rounded-xl p-4 flex items-center gap-4 hover:border-primary transition-colors text-left"
              >
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                  <Car className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="font-bold text-foreground">Lavado de Vehículo</p>
                  <p className="text-xs text-muted-foreground">Combos de lavado exterior e interior</p>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground ml-auto" />
              </button>
              <button
                onClick={() => { setServiceType("tapiceria"); setStep(2); }}
                className="w-full bg-muted border border-border rounded-xl p-4 flex items-center gap-4 hover:border-primary transition-colors text-left"
              >
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                  <Sofa className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="font-bold text-foreground">Tapicería</p>
                  <p className="text-xs text-muted-foreground">Colchones, sillones, alfombras</p>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground ml-auto" />
              </button>
            </div>
          )}

          {step === 2 && serviceType === "lavado" && (
            <div className="space-y-3 mt-2">
              <div className="flex items-center justify-between bg-muted rounded-xl p-3">
                <span className="text-sm text-foreground font-medium">Cantidad de vehículos</span>
                <div className="flex items-center gap-3">
                  <button onClick={() => setVehicleCount(Math.max(1, vehicleCount - 1))} className="w-8 h-8 rounded-full bg-card border border-border flex items-center justify-center">
                    <Minus className="w-4 h-4 text-muted-foreground" />
                  </button>
                  <span className="text-lg font-bold text-primary w-6 text-center">{vehicleCount}</span>
                  <button onClick={() => setVehicleCount(vehicleCount + 1)} className="w-8 h-8 rounded-full bg-card border border-border flex items-center justify-center">
                    <Plus className="w-4 h-4 text-muted-foreground" />
                  </button>
                </div>
              </div>

              {([1, 2, 3, 4, 5] as VehicleCombo[]).map((c) => (
                <button
                  key={c}
                  onClick={() => setCombo(c)}
                  className={`w-full rounded-xl p-4 text-left transition-all border ${
                    combo === c ? "border-primary bg-primary/10 shadow-[0_0_12px_hsl(var(--primary)/0.2)]" : "border-border bg-muted hover:border-primary/50"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-foreground">Combo {c}</span>
                    <span className="text-xs text-primary font-medium">{COMBO_DURATIONS[c]}h por vehículo</span>
                  </div>
                  <ul className="space-y-1">
                    {COMBO_SERVICES[c].map((s) => (
                      <li key={s} className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <Check className="w-3 h-3 text-primary flex-shrink-0" />
                        {s}
                      </li>
                    ))}
                  </ul>
                </button>
              ))}

              <div className="bg-muted rounded-xl p-3 text-center">
                <p className="text-xs text-muted-foreground">Duración estimada</p>
                <p className="text-xl font-bold text-primary">{duration}h</p>
              </div>

              <Button onClick={() => setStep(3)} className="w-full bg-primary text-primary-foreground font-bold">
                Siguiente
              </Button>
            </div>
          )}

          {step === 2 && serviceType === "tapiceria" && (
            <div className="space-y-3 mt-2">
              {tapiceriaConfig.map((item) => {
                const current = tapiceriaItems.find((t) => t.type === item.type);
                const qty = current?.quantity || 0;
                return (
                  <div key={item.type} className="flex items-center justify-between bg-muted rounded-xl p-3">
                    <div>
                      <p className="text-sm font-medium text-foreground">{item.type}</p>
                      <p className="text-[10px] text-muted-foreground">{item.hours}h por unidad</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => updateTapiceria(item.type, -1)} className="w-7 h-7 rounded-full bg-card border border-border flex items-center justify-center">
                        <Minus className="w-3 h-3 text-muted-foreground" />
                      </button>
                      <span className={`text-sm font-bold w-4 text-center ${qty > 0 ? "text-primary" : "text-muted-foreground"}`}>{qty}</span>
                      <button onClick={() => updateTapiceria(item.type, 1)} className="w-7 h-7 rounded-full bg-card border border-border flex items-center justify-center">
                        <Plus className="w-3 h-3 text-muted-foreground" />
                      </button>
                    </div>
                  </div>
                );
              })}

              {tapiceriaItems.length > 0 && (
                <div className="bg-muted rounded-xl p-3 text-center">
                  <p className="text-xs text-muted-foreground">Duración estimada</p>
                  <p className="text-xl font-bold text-primary">{duration}h</p>
                </div>
              )}

              <Button onClick={() => setStep(4)} disabled={tapiceriaItems.length === 0} className="w-full bg-primary text-primary-foreground font-bold">
                Siguiente
              </Button>
            </div>
          )}

          {/* Step 3: Vehicle size selection (lavado only) */}
          {step === 3 && serviceType === "lavado" && (
            <div className="space-y-3 mt-2">
              <p className="text-sm text-muted-foreground">Selecciona el tamaño de tu vehículo:</p>
              {vehicleSizes.map((vs) => (
                <button
                  key={vs.id}
                  onClick={() => setSelectedVehicleSize(vs)}
                  className={`w-full rounded-xl p-4 flex items-center justify-between border transition-all ${
                    selectedVehicleSize?.id === vs.id
                      ? "border-primary bg-primary/10 shadow-[0_0_12px_hsl(var(--primary)/0.2)]"
                      : "border-border bg-muted hover:border-primary/50"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Car className="w-5 h-5 text-primary" />
                    <span className="font-bold text-foreground">{vs.name}</span>
                  </div>
                  <span className="text-primary font-bold text-lg">{vs.price} Bs</span>
                </button>
              ))}

              <Button
                onClick={() => setStep(4)}
                disabled={!selectedVehicleSize}
                className="w-full bg-primary text-primary-foreground font-bold"
              >
                Siguiente
              </Button>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-3 mt-2">
              <div>
                <Label className="text-muted-foreground text-xs">Nombre completo *</Label>
                <Input
                  value={form.clientName}
                  onChange={(e) => setForm({ ...form, clientName: e.target.value })}
                  placeholder="Tu nombre completo"
                  className="bg-muted border-border"
                  maxLength={100}
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-muted-foreground text-xs">Manzana</Label>
                  <Input
                    value={form.manzana}
                    onChange={(e) => setForm({ ...form, manzana: e.target.value })}
                    placeholder="Ej: 5"
                    className="bg-muted border-border"
                    maxLength={10}
                  />
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">Casa</Label>
                  <Input
                    value={form.casa}
                    onChange={(e) => setForm({ ...form, casa: e.target.value })}
                    placeholder="Ej: 12"
                    className="bg-muted border-border"
                    maxLength={10}
                  />
                </div>
              </div>
              <div>
                <Label className="text-muted-foreground text-xs">WhatsApp (opcional)</Label>
                <Input
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="Ej: 59176543210"
                  className="bg-muted border-border"
                  maxLength={20}
                  type="tel"
                />
                <p className="text-[10px] text-muted-foreground mt-0.5">Para que la empresa pueda contactarte si hay algún detalle</p>
              </div>
              <Button onClick={() => setStep(5)} disabled={!form.clientName.trim()} className="w-full bg-primary text-primary-foreground font-bold">
                Siguiente
              </Button>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-3 mt-2">
              <div className="bg-muted rounded-xl p-4 space-y-1">
                <p className="text-xs text-muted-foreground">Resumen</p>
                <p className="text-sm text-foreground font-medium">{form.clientName}</p>
                {form.manzana && <p className="text-xs text-muted-foreground">Mz. {form.manzana} Casa {form.casa}</p>}
                {form.phone && <p className="text-xs text-muted-foreground">📱 {form.phone}</p>}
                <p className="text-xs text-primary font-medium">
                  {serviceType === "lavado"
                    ? `Combo ${combo} × ${vehicleCount} vehículo(s)`
                    : tapiceriaItems.map((i) => `${i.quantity}× ${i.type}`).join(", ")}
                </p>
                {selectedVehicleSize && (
                  <p className="text-xs text-foreground font-medium">
                    🚗 {selectedVehicleSize.name} — <span className="text-primary">{selectedVehicleSize.price} Bs</span>
                  </p>
                )}
                <p className="text-xs text-muted-foreground">Duración: {duration}h</p>
              </div>

              <button
                onClick={() => setPaymentMethod("efectivo")}
                className={`w-full rounded-xl p-4 flex items-center gap-4 border transition-all ${
                  paymentMethod === "efectivo" ? "border-primary bg-primary/10" : "border-border bg-muted"
                }`}
              >
                <CreditCard className="w-6 h-6 text-primary" />
                <span className="font-medium text-foreground">Efectivo</span>
              </button>
              <button
                onClick={() => setPaymentMethod("qr")}
                className={`w-full rounded-xl p-4 flex items-center gap-4 border transition-all ${
                  paymentMethod === "qr" ? "border-primary bg-primary/10" : "border-border bg-muted"
                }`}
              >
                <QrCode className="w-6 h-6 text-primary" />
                <span className="font-medium text-foreground">Pago QR</span>
              </button>

              {/* Show QR image when QR is selected */}
              {paymentMethod === "qr" && adminConfig?.qrImageBase64 && (
                <div className="space-y-3">
                  <div className="bg-white rounded-xl p-4 flex justify-center">
                    <img src={adminConfig.qrImageBase64} alt="QR de Pago" className="w-48 h-48 object-contain" />
                  </div>
                  <Button
                    onClick={handleDownloadQR}
                    variant="outline"
                    className="w-full border-primary/50 text-primary hover:bg-primary/10"
                  >
                    <Download className="w-4 h-4 mr-2" /> Descargar QR
                  </Button>
                </div>
              )}

              <Button onClick={handleBook} className="w-full bg-primary text-primary-foreground font-bold text-base py-5">
                Confirmar Servicio
              </Button>
            </div>
          )}

          {step > 1 && (
            <button onClick={goBack} className="text-xs text-muted-foreground hover:text-primary mt-1">
              ← Volver
            </button>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={showCancel} onOpenChange={setShowCancel}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-primary">Cancelar Servicio</DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">Ingresa tu nombre para cancelar tu servicio de hoy</p>
          <Input
            value={cancelName}
            onChange={(e) => setCancelName(e.target.value)}
            placeholder="Tu nombre"
            className="bg-muted border-border"
            maxLength={100}
          />
          <Button onClick={handleCancel} variant="destructive" className="w-full font-bold">
            <X className="w-4 h-4 mr-2" /> Cancelar Servicio
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default TimeSlotsGrid;
