-- Create table to store daily reports
CREATE TABLE public.daily_reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  report_date TEXT NOT NULL UNIQUE,
  appointments_data JSONB NOT NULL DEFAULT '[]',
  total_earnings NUMERIC NOT NULL DEFAULT 0,
  total_services INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.daily_reports ENABLE ROW LEVEL SECURITY;

-- Policies for public access (same as other tables)
CREATE POLICY "Anyone can read reports" ON public.daily_reports FOR SELECT USING (true);
CREATE POLICY "Anyone can insert reports" ON public.daily_reports FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update reports" ON public.daily_reports FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete reports" ON public.daily_reports FOR DELETE USING (true);