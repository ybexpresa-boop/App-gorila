ALTER TABLE public.admin_config 
ADD COLUMN break_enabled boolean NOT NULL DEFAULT true,
ADD COLUMN break_start text NOT NULL DEFAULT '12:00',
ADD COLUMN break_end text NOT NULL DEFAULT '12:30';