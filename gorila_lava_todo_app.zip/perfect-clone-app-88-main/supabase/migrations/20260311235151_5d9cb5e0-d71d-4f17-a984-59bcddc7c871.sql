
-- Create vehicle sizes table for admin to manage vehicle types and prices
CREATE TABLE public.vehicle_sizes (
  id serial PRIMARY KEY,
  name text NOT NULL,
  price numeric NOT NULL DEFAULT 0,
  sort_order integer NOT NULL DEFAULT 0
);

-- Enable RLS
ALTER TABLE public.vehicle_sizes ENABLE ROW LEVEL SECURITY;

-- Public read
CREATE POLICY "Anyone can read vehicle_sizes" ON public.vehicle_sizes FOR SELECT TO public USING (true);
CREATE POLICY "Anyone can insert vehicle_sizes" ON public.vehicle_sizes FOR INSERT TO public WITH CHECK (true);
CREATE POLICY "Anyone can update vehicle_sizes" ON public.vehicle_sizes FOR UPDATE TO public USING (true);
CREATE POLICY "Anyone can delete vehicle_sizes" ON public.vehicle_sizes FOR DELETE TO public USING (true);

-- Add vehicle_size_name column to appointments
ALTER TABLE public.appointments ADD COLUMN vehicle_size_name text;
ALTER TABLE public.appointments ADD COLUMN vehicle_size_price numeric;

-- Insert default vehicle sizes
INSERT INTO public.vehicle_sizes (name, price, sort_order) VALUES
  ('Auto Pequeño', 50, 1),
  ('Auto Mediano', 70, 2),
  ('Auto Grande', 90, 3),
  ('Camioneta / SUV', 120, 4);
