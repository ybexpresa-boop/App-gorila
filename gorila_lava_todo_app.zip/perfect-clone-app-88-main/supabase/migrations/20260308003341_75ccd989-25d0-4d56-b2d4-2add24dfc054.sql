
-- Create appointments table
CREATE TABLE public.appointments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  client_name TEXT NOT NULL,
  manzana TEXT DEFAULT '',
  casa TEXT DEFAULT '',
  phone TEXT DEFAULT '',
  service_type TEXT NOT NULL CHECK (service_type IN ('lavado', 'tapiceria')),
  vehicle_count INTEGER,
  combo INTEGER CHECK (combo IN (1, 2, 3, 4, 5)),
  tapiceria_items JSONB,
  payment_method TEXT NOT NULL CHECK (payment_method IN ('efectivo', 'qr')),
  duration_hours NUMERIC NOT NULL,
  status TEXT NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente', 'en_proceso', 'completado', 'cancelado')),
  price NUMERIC,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read appointments" ON public.appointments FOR SELECT USING (true);
CREATE POLICY "Anyone can insert appointments" ON public.appointments FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update appointments" ON public.appointments FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete appointments" ON public.appointments FOR DELETE USING (true);

-- Create work_schedule table
CREATE TABLE public.work_schedule (
  day_of_week INTEGER PRIMARY KEY CHECK (day_of_week >= 0 AND day_of_week <= 6),
  enabled BOOLEAN NOT NULL DEFAULT true,
  start_time TEXT NOT NULL DEFAULT '08:30',
  end_time TEXT NOT NULL DEFAULT '16:00',
  interval_minutes INTEGER NOT NULL DEFAULT 30
);

ALTER TABLE public.work_schedule ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read schedule" ON public.work_schedule FOR SELECT USING (true);
CREATE POLICY "Anyone can update schedule" ON public.work_schedule FOR UPDATE USING (true);

INSERT INTO public.work_schedule (day_of_week, enabled, start_time, end_time, interval_minutes) VALUES
  (0, false, '08:30', '16:00', 30),
  (1, true, '08:30', '16:00', 30),
  (2, true, '08:30', '16:00', 30),
  (3, true, '08:30', '16:00', 30),
  (4, true, '08:30', '16:00', 30),
  (5, true, '08:30', '16:00', 30),
  (6, true, '08:30', '16:00', 30);

-- Create admin_config table
CREATE TABLE public.admin_config (
  id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  whatsapp_number TEXT DEFAULT '',
  qr_image_base64 TEXT DEFAULT ''
);

ALTER TABLE public.admin_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read config" ON public.admin_config FOR SELECT USING (true);
CREATE POLICY "Anyone can update config" ON public.admin_config FOR UPDATE USING (true);
CREATE POLICY "Anyone can insert config" ON public.admin_config FOR INSERT WITH CHECK (true);

INSERT INTO public.admin_config (id, whatsapp_number, qr_image_base64) VALUES (1, '', '');

-- Create tapiceria_items table
CREATE TABLE public.tapiceria_items (
  id SERIAL PRIMARY KEY,
  type TEXT NOT NULL,
  hours NUMERIC NOT NULL DEFAULT 2
);

ALTER TABLE public.tapiceria_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read tapiceria" ON public.tapiceria_items FOR SELECT USING (true);
CREATE POLICY "Anyone can insert tapiceria" ON public.tapiceria_items FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update tapiceria" ON public.tapiceria_items FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete tapiceria" ON public.tapiceria_items FOR DELETE USING (true);

INSERT INTO public.tapiceria_items (type, hours) VALUES
  ('Colchón Individual', 2),
  ('Colchón Matrimonial', 2.5),
  ('Colchón Queen/King', 3),
  ('Sillón Individual', 2),
  ('Sillón Doble', 3),
  ('Sillón Largo (3+)', 4),
  ('Alfombra', 1.5),
  ('Silla de Auto', 1);

CREATE INDEX idx_appointments_date ON public.appointments (date);
